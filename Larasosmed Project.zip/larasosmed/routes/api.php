<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Api\v1\AuthController;
use App\Http\Controllers\Api\v1\UserController;
use App\Http\Controllers\Api\v1\FeedController;
/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "api" middleware group. Make something great!
|
*/

// Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
//     return $request->user();
// });

Route::prefix('v1')->group(function(){
    Route::post('login',[AuthController::class, 'login'])->name('login');
    Route::post('register',[AuthController::class, 'register'])->name('register');
    
    Route::middleware('auth:api')->group( function () {
        Route::get('profile',[AuthController::class, 'profile'])->name('profile');
        Route::get('logout',[AuthController::class, 'logout'])->name('logout');

        Route::resource('user', UserController::class);
        Route::put('user/password/{id}', [UserController::class, 'updatePassword'])->name('updatePassword');
        Route::get('user/followers/{id}', [UserController::class, 'followers'])->name('followers');
        Route::get('user/following/{id}', [UserController::class, 'following'])->name('following');
        Route::post('user/follow/{id}', [UserController::class, 'follow'])->name('follow');
        Route::post('user/unfollow/{id}', [UserController::class, 'unfollow'])->name('unfollow');

        Route::resource('feed', FeedController::class);
        Route::get('feed/like/{id}', [FeedController::class, 'list_like'])->name('list_like');
        Route::post('feed/like/{id}', [FeedController::class, 'like'])->name('like');
        Route::post('feed/unlike/{id}', [FeedController::class, 'unlike'])->name('unlike');
        Route::get('feed/comment/{id}', [FeedController::class, 'list_comment'])->name('list_comment');
        Route::post('feed/comment/{id}', [FeedController::class, 'comment'])->name('comment');
        Route::post('feed/uncomment/{id}', [FeedController::class, 'uncomment'])->name('uncomment');
        Route::get('feed/share/{id}', [FeedController::class, 'list_share'])->name('list_share');
        Route::post('feed/share/{id}', [FeedController::class, 'share'])->name('share');

    });
});
