<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

use App\Models\BaseModels;

class Feed extends BaseModels
{
    use HasFactory;

    protected $table = 'feed';
    protected $primaryKey = 'id';
    protected $keyType = 'string';
    public $incrementing = false;

    protected $guarded = [];


    public function getIncrementing()
    {
        return false;
    }

    public function getKeyType()
    {
        return 'string';
    }

    public function data_attachment() {
        return $this->hasMany(FeedAttachment::class, 'id_feed');
    }
    public function data_like() {
        return $this->hasMany(FeedLike::class, 'id_feed');
    }
    public function data_comment() {
        return $this->hasMany(FeedComment::class, 'id_feed');
    }
    public function data_share() {
        return $this->hasMany(FeedShare::class, 'id_feed');
    }
}
