<?php

namespace App\Models;
 
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;
use Carbon\Carbon;
use Illuminate\Support\Str;

class BaseModels extends Model
{
    public static function boot() {
        parent::boot();
        
        static::creating(function($model)
        {  

            if (!$model->getKey()) {
                $model->{$model->getKeyName()} = (string) Str::uuid();
            }
        });
 
        static::updating(function($model)
        { 
            // 
        });
 
 
    }

}