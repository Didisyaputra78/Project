<?php

namespace App\Http\Controllers\Api\v1;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Feed;
use App\Models\FeedLike;
use App\Models\FeedComment;
use App\Models\FeedShare;
use App\Models\FeedAttachment;
use Validator;
use Carbon\Carbon;
use Illuminate\Validation\Rule;
use DB;
use Omjin;


class FeedController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        try {

            $skip = (int) isset($request->skip) ? $request->skip : 0;
            $take = (int) isset($request->take) ? $request->take : 10;
    
            $qry = Feed::with(['data_attachment', 
            // 'data_comment' => function($q) {
            //     $q->whereNull('id_parent');
            // }, 'data_comment.data_reply'
            ])->withCount([ 'data_like', 'data_comment', 'data_share']);
            
            $data = $qry->skip($skip)->take($take)->get();

            return $this->successResponse('Success', $data);
        } catch (\Throwable $e) {
            return $this->errorResponse($e->getMessage(), $e->getMessage(), 500);
        }
    }

    public function list_like(Request $request, string $id)
    {
        try {

            $skip = (int) isset($request->skip) ? $request->skip : 0;
            $take = (int) isset($request->take) ? $request->take : 10;
    
            $qry = FeedLike::select('feed_like.*', 'users.first_name', 'users.last_name', 'users.username')
                            ->leftJoin('users', 'users.id', '=', 'feed_like.id_user')
                            ->where('id_feed', $id);
            
            $data = $qry->skip($skip)->take($take)->get();

            return $this->successResponse('Success', $data);
        } catch (\Throwable $e) {
            return $this->errorResponse($e->getMessage(), $e->getMessage(), 500);
        }
    }

    public function list_comment(Request $request, string $id)
    {
        try {

            $skip = (int) isset($request->skip) ? $request->skip : 0;
            $take = (int) isset($request->take) ? $request->take : 10;
    
            $qry = FeedComment::with(['data_reply' => function($q) {
                                    $q->select('feed_comment.*', 'users.first_name', 'users.last_name', 'users.username')
                                    ->leftJoin('users', 'users.id', '=', 'feed_comment.id_user');
                                }])
                                ->select('feed_comment.*', 'users.first_name', 'users.last_name', 'users.username')
                                ->leftJoin('users', 'users.id', '=', 'feed_comment.id_user')
                                ->where('id_feed', $id)
                                ->whereNull('id_parent');
            
            $data = $qry->skip($skip)->take($take)->get();

            return $this->successResponse('Success', $data);
        } catch (\Throwable $e) {
            return $this->errorResponse($e->getMessage(), $e->getMessage(), 500);
        }
    }

    public function list_share(Request $request, string $id)
    {
        try {

            $skip = (int) isset($request->skip) ? $request->skip : 0;
            $take = (int) isset($request->take) ? $request->take : 10;
    
            $qry = FeedShare::select('feed_share.*', 'users.first_name', 'users.last_name', 'users.username')
                            ->leftJoin('users', 'users.id', '=', 'feed_share.id_user')
                            ->where('id_feed', $id);
            
            $data = $qry->skip($skip)->take($take)->get();

            return $this->successResponse('Success', $data);
        } catch (\Throwable $e) {
            return $this->errorResponse($e->getMessage(), $e->getMessage(), 500);
        }
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $id_user = trim($request->id_user);
        $caption = trim($request->caption);
        $attachment = $request->attachment;

        $validator = Validator::make($request->all(),[
            'id_user' => 'required',
            'caption' => 'required',
            'attachment' => 'required',
        ]);
        if ($validator->fails()){
            return response()->json(['error'=>$validator->errors()],401);
        }

        try {
            
            $qry = Feed::create([
                'id_user' => $id_user,
                'caption' => $caption
            ]);

            $lastId = $qry->id;


            foreach ($attachment as $key => $item) {
                $file_attachment_rename = 'feed_'. Omjin::generateUniqueID(8).'.'.$item->getClientOriginalExtension();
                $path_file_attachment = public_path("storage/feed/");
        
                $up = $item->move($path_file_attachment, $file_attachment_rename);

                if($up){
                    FeedAttachment::create([
                        'id_feed' => $lastId,
                        'attachment' => $file_attachment_rename,
                    ]);
                }
            }


			return $this->successResponse('Success upload feed', null);
        } catch (\Throwable $e) {
            return $this->errorResponse($e->getMessage(), $e->getMessage(), 500);
        }
    }

    public function like(Request $request, string $id)
    {
        $id_user = trim($request->id_user);

        $validator = Validator::make($request->all(),[
            'id_user' => 'required',
        ]);
        if ($validator->fails()){
            return response()->json(['error'=>$validator->errors()],401);
        }

        try {
            
            $data = FeedLike::create([
                'id_feed' => $id,
                'id_user' => $id_user
            ]);

			return $this->successResponse('Success like feed', null);
        } catch (\Throwable $e) {
            return $this->errorResponse($e->getMessage(), $e->getMessage(), 500);
        }

    }

    public function unlike(Request $request, string $id)
    {
        $id_user = trim($request->id_user);

        $validator = Validator::make($request->all(),[
            'id_user' => 'required',
        ]);
        if ($validator->fails()){
            return response()->json(['error'=>$validator->errors()],401);
        }

        try {
            
            $data = FeedLike::where([
                'id_feed' => $id,
                'id_user' => $id_user
            ])->delete();

			return $this->successResponse('Success unlike feed', null);
        } catch (\Throwable $e) {
            return $this->errorResponse($e->getMessage(), $e->getMessage(), 500);
        }

    }

    public function comment(Request $request, string $id)
    {
        $id_user = trim($request->id_user);
        $id_parent = trim($request->id_parent);
        $comment = trim($request->comment);

        $validator = Validator::make($request->all(),[
            'id_user' => 'required',
            'comment' => 'required',
        ]);
        if ($validator->fails()){
            return response()->json(['error'=>$validator->errors()],401);
        }

        try {
            
            $data = FeedComment::create([
                'id_feed' => $id,
                'id_user' => $id_user,
                'id_parent' => $id_parent ? $id_parent : null,
                'comment' => $comment
            ]);

			return $this->successResponse('Success add comment', null);
        } catch (\Throwable $e) {
            return $this->errorResponse($e->getMessage(), $e->getMessage(), 500);
        }

    }

    public function uncomment(Request $request, string $id)
    {

        try {
            
            $data = FeedComment::where([
                'id' => $id
            ])->delete();

			return $this->successResponse('Success delete comment', null);
        } catch (\Throwable $e) {
            return $this->errorResponse($e->getMessage(), $e->getMessage(), 500);
        }

    }

    public function share(Request $request, string $id)
    {
        $id_user = trim($request->id_user);

        $validator = Validator::make($request->all(),[
            'id_user' => 'required',
        ]);
        if ($validator->fails()){
            return response()->json(['error'=>$validator->errors()],401);
        }

        try {
            
            $data = FeedShare::create([
                'id_feed' => $id,
                'id_user' => $id_user,
            ]);

			return $this->successResponse('Success share', null);
        } catch (\Throwable $e) {
            return $this->errorResponse($e->getMessage(), $e->getMessage(), 500);
        }

    }


    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        $caption = trim($request->caption);

        
		if (!$caption)
		{
            return $this->successResponse('No data updated', null);
		}


        DB::beginTransaction();
        try {
            
            // update akomodasi
            $data = [];

            if($caption){
                $data['caption'] = $caption;
            }

            if(count($data) > 0){
                $qry = Feed::find($id)->update($data);
        
            }


            DB::commit();
			return $this->successResponse('Feed successfully updated.', null);
        } catch (\Throwable $e) {
            DB::rollback();
            return $this->errorResponse($e->getMessage(), $e->getMessage(), 500);
        }
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }
}
