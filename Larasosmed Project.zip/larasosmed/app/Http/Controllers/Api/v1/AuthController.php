<?php

namespace App\Http\Controllers\Api\v1;
use App\Models\User;
use Validator;
use Carbon\Carbon;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;

class AuthController extends Controller
{
    
    public function register(Request $request){
        //validation
        $validator = Validator::make($request->all(),[
            'first_name' => 'required',
            'date_of_birth' => 'required',
            'phone_number' => 'required|numeric|digits_between:1,20',
            'email'    => 'required|email|unique:users',
            'username' => 'required',
            'password' => 'required|min:8',
            're_password' => 'required|same:password',
        ]);
        if ($validator->fails()){
            return response()->json(['error'=>$validator->errors()],401);
        }
        $input = $request->all();
        // dd(Carbon::parse($input['date_of_birth']));
        $input['password'] = bcrypt($input['password']);
        $input['date_of_birth'] = Carbon::parse($input['date_of_birth']);
        //save to database
        $user = User::create($input);
        
        $data['username']  = $user->username;

        return $this->successResponse('Success', $data);
    }
    
    public function login(Request $request){
        $validator = Validator::make($request->all(),[
            'username' => 'required',
            'password' => 'required',
        ]);
        
        if(Auth::attempt(['username' => $request->username, 'password' => $request->password])){
            $user = Auth::user();
            $tokenResult =  $user->createToken('Personal Access Token');
            $token = $tokenResult->token;
            if($request->remember_me){
                $token->expires_at = Carbon::now()->addWeeks(1);
            }
            $token->save();

            $data = [
                'access_token'=>$tokenResult->accessToken,
                'token_type' => 'Bearer', 
                'expires_at' => Carbon::parse($tokenResult->token->expires_at)->toDateTimeString()
            ];

            return $this->successResponse('Success', $data);

        }else{
            return $this->errorResponse('Unauthorize', 'Unauthorize', 401);
        }
    }

    public function profile(Request $request){
        $data = User::with(['data_followers'])->get();
        return $this->successResponse('Success', $data);
    }

    
    public function logout(Request $request){
        $request->user()->token()->revoke();
        return $this->successResponse('Success', 'User logged out');
    }
}