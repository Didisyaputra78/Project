<?php

namespace App\Http\Controllers\Api\v1;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Following;
use App\Models\Followers;
use Validator;
use Carbon\Carbon;
use Illuminate\Validation\Rule;
use DB;


class UserController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        try {

            $skip = (int) isset($request->skip) ? $request->skip : 0;
            $take = (int) isset($request->take) ? $request->take : 10;
    
            $qry = User::whereNotNull('id');
            
            $dt = $qry->skip($skip)->take($take)->get();

            $data = [];
            foreach($dt as $key => $item){
                $followers = $item->data_followers($item->id)->count();
                $following = $item->data_following($item->id)->count();

                $item['data_followers_count'] = $followers;
                $item['data_following_count'] = $following;

                $data[] = $item;
            }

            return $this->successResponse('Success', $data);
        } catch (\Throwable $e) {
            return $this->errorResponse($e->getMessage(), $e->getMessage(), 500);
        }
    }

    public function followers(Request $request, string $id)
    {
        try {

            $skip = (int) isset($request->skip) ? $request->skip : 0;
            $take = (int) isset($request->take) ? $request->take : 10;
    
            $qry = Following::select('following.*', 'users.first_name', 'users.last_name', 'users.username')
                            ->leftJoin('users', 'users.id', '=', 'following.id_user')
                            ->where('following', $id);
            
            $data = $qry->skip($skip)->take($take)->get();

            return $this->successResponse('Success', $data);
        } catch (\Throwable $e) {
            return $this->errorResponse($e->getMessage(), $e->getMessage(), 500);
        }
    }
    public function following(Request $request, string $id)
    {
        try {

            $skip = (int) isset($request->skip) ? $request->skip : 0;
            $take = (int) isset($request->take) ? $request->take : 10;
    
            $qry = Following::select('following.*', 'users.first_name', 'users.last_name', 'users.username')
                            ->leftJoin('users', 'users.id', '=', 'following.following')
                            ->where('id_user', $id);
            
            $data = $qry->skip($skip)->take($take)->get();

            return $this->successResponse('Success', $data);
        } catch (\Throwable $e) {
            return $this->errorResponse($e->getMessage(), $e->getMessage(), 500);
        }
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    public function follow(Request $request, string $id)
    {
        $following = trim($request->following);

        $validator = Validator::make($request->all(),[
            'following' => 'required',
        ]);
        if ($validator->fails()){
            return response()->json(['error'=>$validator->errors()],401);
        }

        try {
            
            $data = Following::create([
                'id_user' => $id,
                'following' => $following
            ]);

			return $this->successResponse('Success follow', null);
        } catch (\Throwable $e) {
            return $this->errorResponse($e->getMessage(), $e->getMessage(), 500);
        }

    }

    public function unfollow(Request $request, string $id)
    {
        $following = trim($request->following);

        $validator = Validator::make($request->all(),[
            'following' => 'required',
        ]);
        if ($validator->fails()){
            return response()->json(['error'=>$validator->errors()],401);
        }

        try {
            
            $data = Following::where([
                'id_user' => $id,
                'following' => $following
            ])->delete();

			return $this->successResponse('Success unfollow', null);
        } catch (\Throwable $e) {
            return $this->errorResponse($e->getMessage(), $e->getMessage(), 500);
        }

    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        try {
            
            $data = User::with(['data_followers', 'data_following'])->find($id);

			return $this->successResponse('Found.', $data);
        } catch (\Throwable $e) {
            return $this->errorResponse($e->getMessage(), $e->getMessage(), 500);
        }
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        $first_name = trim($request->first_name);
        $last_name = trim($request->last_name);
        $username = trim($request->username);
        $email = trim($request->email);
        $phone_number = trim($request->phone_number);
        $date_of_birth = Carbon::parse(trim($request->date_of_birth));

        
		if (!$first_name &&
        !$last_name &&
        !$username &&
        !$email &&
        !$phone_number &&
        !$date_of_birth)
		{
            return $this->successResponse('No data updated', null);
		}

        $validator = Validator::make($request->all(),[
            'phone_number' => 'numeric|digits_between:1,20|unique:users,id,'.$id,
            'email'    => 'unique:users,id,'.$id,
            'username' => 'unique:users,id,'.$id,
        ]);

        if ($validator->fails()){
            return response()->json(['error'=>$validator->errors()],401);
        }


        DB::beginTransaction();
        try {
            
            // update akomodasi
            $data = [];

            if($first_name){
                $data['first_name'] = $first_name;
            }
            if($last_name){
                $data['last_name'] = $last_name;
            }
            if($email){
                $data['email'] = $email;
            }
            if($phone_number){
                $data['phone_number'] = $phone_number;
            }
            if($date_of_birth){
                $data['date_of_birth'] = $date_of_birth;
            }

            if(count($data) > 0){
                $qry = User::find($id)->update($data);
        
            }


            DB::commit();
			return $this->successResponse('User successfully updated.', null);
        } catch (\Throwable $e) {
            DB::rollback();
            return $this->errorResponse($e->getMessage(), $e->getMessage(), 500);
        }
    }

    public function updatePassword(Request $request, string $id)
    {
        $password = trim($request->password);
        $re_password = trim($request->re_password);

        
		if (!$password &&
        !$re_password)
		{
            return $this->successResponse('No data updated', null);
		}

        $validator = Validator::make($request->all(),[
            'password' => 'required|min:8',
            're_password' => 'required|same:password',
        ]);

        if ($validator->fails()){
            return response()->json(['error'=>$validator->errors()],401);
        }


        DB::beginTransaction();
        try {
            
            // update akomodasi
            $data = [];

            if($password){
                $data['password'] = bcrypt($password);
            }

            if(count($data) > 0){
                $qry = User::find($id)->update($data);
            }


            DB::commit();
			return $this->successResponse('Password successfully updated.', null);
        } catch (\Throwable $e) {
            DB::rollback();
            return $this->errorResponse($e->getMessage(), $e->getMessage(), 500);
        }
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        DB::beginTransaction();
        try {

            $qry = User::find($id)->delete();

            DB::commit();
			return $this->successResponse('User successfully deleted.', null);
        } catch (\Throwable $e) {
            DB::rollback();
            return $this->errorResponse($e->getMessage(), $e->getMessage(), 500);
        }
    }
}
